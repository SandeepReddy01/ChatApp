=== JivoChat - a Live Chat for Your Site [Official] ===
Contributors: JivoChat
Donate link: http://jivochat.com/
Tags: jivochat, chat for website, banckle, Chat, chat online, chat software, click desk, clickdesk, contact plugin, contact us, customer support, free chat, IM Chat, live chat, live chat inc, live chat services, live chat software, live chatting, live help, live support, live web chat, livechat, olark, online chat, online support, php live chat, snapengage, support software, Website Chat, WordPress chat, wordpress live chat, wordpress live chat plugin, zendesk, Zopim, Zopim live chat, jivosite, живосайт, живой сайт
Requires at least: 3.0.1
Tested up to: 4.0
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

With JivoChat you can chat with visitors on your website to increase conversion and sales. Free version is available!

== Description ==

JivoChat helps curious customers receive immediate answers in live chat - without having to call or send emails and right on your website! Be quick about answering your buyers, and the conversion on your website will increase dramatically.



= How it Works =

* **Plugs Right In:** Installs in minutes, and can be custom configured to match your personal style.
* **Goes Everywhere:** Agents can take chats with our convenient desktop app for Mac/Windows, our browser app and our mobile app too!
* **5X Conversions:** Offering assistance before questions are asked with proactive chats turns casual visitors into happy customers.
 


= Why JivoChat? =

* **60,000 websites** help over 1.5 million customers per month with JivoChat
* We’re clean and cool. JivoChat is simple, beautiful and convenient. The chat window doesn’t disappear or reload when navigating between pages.
* We’ll make you more efficient. The average employee can handle up to 5 chats at once, but only 1 phone call.
* We offer a completely free edition that works for up to 5 agents, forever.
 
 
 
= For Geeks Only =
* Messages are delivered instantaneously over websockets, with fallback to HTTPS available
* 100% reliability, with a scalable and fault-tolerant geographically-distributed backend on Amazon
* Desktop agent app works on Win/Mac, browser-based app and mobile app available.
* SSL Encryption of all communications for privacy

Questions? We use JivoChat, too. Just reach out to us through live chat at [JivoChat.com](http://www.jivochat.com) or send an email to support@jivochat.com. Once you’ve found your answers, download the JivoChat plugin today. Your free account will be created upon installation!
 

== Installation ==

* Install and activate the Wordpress Plugin
* After installation, click the JivoChat section in the left toolbar
* Create a new JivoChat account, or use your existing one
* Download and install the agent's app on your computer or mobile, or use our browser-based app


== Frequently Asked Questions ==

= Can I use JivoChat for free? =

Absolutely! You can use JivoChat for free with up to 5 online agents and with limited features. For the first 14 days all features will be available too.

= Do I need any software on my server for JivoChat to work? =

No, you don't! JivoChat is a SaaS service, which means all the server stuff is on us. You just need to install the Wordpress module, and you're all set.

= How will I receive messages from my customers? =

You can choose to install the desktop app, or you can install our JivoChat app on your iOS or android device, or you can use our web-based app right in your browser!

== Screenshots ==

1. The chat window is fully customizable
2. You can use the desktop, mobile or browser-based agent application

== Changelog ==

= 1.0 =
* Welcome our very first version of the plugin!
