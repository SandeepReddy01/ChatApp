<script type='text/javascript'>
    (function(){ var widget_id = '<?php echo $widget_id; ?>';
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//<?php echo JIVOSITE_WIDGET_URL; ?>/script/widget/'+widget_id+'?plugin=wp'; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);})();
</script>